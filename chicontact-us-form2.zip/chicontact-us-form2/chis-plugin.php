<?php

/**

*Plugin Name: chis contact plugin New
*Plugin URI: webzify.com
*Author: Akagha Chinaka
Version 1.0
License

**/

require_once'chis-plugin-form.php';
require_once'database_table.php';

chi_messages_short_code_handler();

add_shortcode('chi_messages','chi_messages_short_code_handler');

function chis_contact_form_add_admin_page(){
?>

<!-- beginning of stylesheet for this plugin-->

<style>

.view-messages-container{
	width:100%;
	float:left;
	padding: 10px;
	background:silver;
	font-size:30px;
	font-family:"Open Sans",sans-serif;
}

.main-message{
	width:98%;
	float:left;
	background:skyblue;
	padding:10px;
	border-radius:10px;
	margin-left:auto;
	margin-right:auto;
}

#senders-message{
	display:none;
}


.text-form-admin-container{
	width:70%;
	margin-top: 50px;
}

.text-form-admin{
	float:left;
	width:50%;
	margin-top:10px;
	border:1px solid skyblue !important;
}

.textarea-form-admin{
	float:left;
	width:50%;
	margin-top:10px;
	border:1px solid skyblue;
}

.btn-form-admin-container{
	float:left;
	width:70%;
	margin-top:30px;
}

.submit-btn{

	float:left;

}

.text_notification{
	float:left;
	background:#fff;
	width:50%;
	border-left:3px solid #46b450;
	text-align:center;
	padding: 10px;

}

</style>

<?php	
	//generate chi messages page
	add_menu_page(
		'Chis Messages', 'Chis Messages', 'manage_options', 'chis_messages', 'chis_contact_form_create_page','dashicons-email','110'
	);

	// generate chimessages admin subpage
	add_submenu_page('chis_messages','View Messages','View Messages','manage_options','chis_messages','chis_contact_form_display_messages');
	//for seetings page
	add_submenu_page('chis_messages','Settings','Settings','manage_options','chis_messages_settings','display_form_field');
	//for viewing the full message
	add_submenu_page('chis_messages','senders-message','Senders Message','manage_options','senders_message','chis_contact_form_view_messages');

	//Activate custom settings
	add_action('admin_init','chis_messages_custom_settings');
}

add_action('admin_menu','chis_contact_form_add_admin_page');

function chis_messages_custom_settings(){
	register_setting('chis-messages-settings-group','senders_name');

	add_settings_section('chis-messages-options','Messages Options','chis_messages_options','chis_messages');

	add_settings_field('field-name','First Name','display_form_field','chis_messages','chis-messages-options');
}


function chis_messages_options(){

echo'customize your message settings';
}



function chis_contact_form_create_page(){

	function add_css_stylesheet(){

		wp_register_style( 'my-plugin', plugins_url( 'chicontact-us-form2/style.css' ) );
		//wp_enqueue_style('add_css',plugin_url( __FILE__ ).'chicontact-us-form2/style.css');
		wp_enqueue_style('my-plugin');
	}

				add_action('admin_enqueue_scripts','add_css_stylesheet');

	//messages will be displayed such that when they are clicked, they get dispayed in a drop down
	echo'<h1>Chis Messages Display Page</h1>';
}


//here is the former callback function for the settings page
/*
function chis_contact_form_settings_page(){

	require_once'chis-plugin-form.php';
}
*/

//setup database table
function chis_contact_form_display_messages(){


	global $jal_db_version;
	$jal_db_version = '1.0';
	//call database function
	jal_install1();

	jal_install2();

global $wpdb;
$table_name=$wpdb->prefix . 'chis_messages_settings';
$messages=$wpdb->get_results("SELECT * FROM $table_name WHERE `id`='1'");
if($wpdb->num_rows<1){
jal_install_data();
}
global $wpdb;
$table_name=$wpdb->prefix . 'chis_messages';
$messages=$wpdb->get_results("SELECT * FROM $table_name");
//'Display Messages <a href="http://localhost/my-site2/wp-admin/admin.php?page=chis_messages&id=1">view</a> get_template_directory_uri()';

echo $messages->name;
?>

<?php $url = plugin_dir_url( $file );  $url2 = plugins_url( $file ); 

	//echo $url; echo $url2;
?>
	<table class="wp-list-table widefat fixed striped posts">
		<thead>
			<tr>
				<td>ID</td>
				<td>NAME</td>
				<td>SUBJECT</td>
				<td>EMAIL</td>
			</tr>
		</thead>
		<tbody id="the-list" data-wp-lists='list:post'>
	<?php

	foreach ($messages as $message) {

	?>		
			<tr>
				<td><br><?php echo $message->id ?></td>
				<td><br><a href="http://localhost/my-site2/wp-admin/admin.php?page=senders_message&id=<?php echo $message->id ?>"><?php echo $message->name ?></a></td>
				<td><br><?php echo $message->subject ?></td>
				<td><br><?php echo $message->email ?></td>
			</tr>
<?php

	}
?>
	</tbody>
	</table>

<?php

}


// call back function for displaying the full message
function chis_contact_form_view_messages(){

	if (isset($_GET['page'],$_GET['id']) && $_GET['page']=='senders_message') {

		global $wpdb;
		$id=$_GET['id'];
		$table_name=$wpdb->prefix . 'chis_messages';
		$senders_full_message=$wpdb->get_results("SELECT * FROM $table_name WHERE `id`='$id'");
?>

		<table class="wp-list-table widefat fixed striped posts view_messages_container">
			<strong class="view-messages-container">

<?php
		foreach ($senders_full_message as $senders_full_messages) {
?>			
					
			<?php 
				echo'<tr>';
					echo'<td><h4>SENDERS NAME:</h4> '.$senders_full_messages->name.'</td>';
				echo'</tr>';

				echo'<tr>';
					echo'<td><h4>SENDERS EMAIL:</h4> '.$senders_full_messages->email.'</td>';
				echo'</tr>';

				echo'<tr>';
					echo'<td><h4>SENDERS SUBJECT:</h4> '.$senders_full_messages->subject.'</td>'; 
				echo'</tr>'; 
			?>
		
			<?php 

				echo'<tr>';
				echo'<td><h4>SENDERS MESSAGE:</h4><div class="main-message">'.$senders_full_messages->message.'</div></td>';
				echo'<tr>';
			?>
			
<?php
			
		}
		echo'
			</strong>
		</table>';

	}
}

?>
