<?php // settings_errors(); ?>


<?php
function display_settings_form(){

echo 'chinka';

}


function chi_messages_short_code_handler(){
global $wpdb;
		
		//if table doesnt already exist, create it
		/*$table=$wpdb->prefix . "chis_messages";
		$charset_collate=$wpdb->get_charset_collate();
		$sql="CREATE TABLE IF NOT EXISTS $table (`id` mediumint(9) NOT NULL AUTO_INCREMENT,`name` text NOT NULL, UNIQUE (`id`)) $charset_collate;";*/

		if (isset($_POST['save_chis_message'])) {
			$senders_email=$_POST['senders_email']; $senders_name=$_POST['senders_name']; 
			$senders_subject=$_POST['senders_subject']; $senders_message=$_POST['senders_message'];
			//insert users message into the database
			//exit;
			//header("Location:dkjdkjdfkjd.php");
			$table_name = $wpdb->prefix . 'chis_messages';
			$wpdb->insert(
				$table_name,
				array(
						'email'=>$senders_email,
						'name'=>$senders_name,
						'subject'=>$senders_subject,
						'message'=>$senders_message
					)
			);

			global $wpdb;
			$table_name2=$wpdb->prefix . 'chis_messages_settings';
			$messages=$wpdb->get_results("SELECT * FROM $table_name2");
			foreach ($messages as $message) {
				//$admins_email=$message->admin_email;
				$admin_subject=$message->admin_subject;
				$admin_message_body=$message->admin_message_body;

				//$admins_subject='New Message From webzify';
				//$admins_Message='Thanks for your response. we will get back to you shoortly';
				//send an email notofication to the user and admin
				wp_mail($senders_email,$admin_subject,$admin_message_body);
				//wp_mail('akaghachinaka@gmail.com', 'subject', 'message');
				
			}
		}


		return
	'
		<div id="chis_plugin_form">
			<form action="#v_form" method="post" id="v_form">
				<input type="text" name="senders_name" placeholder="Your Name" id="input-fields" class="chis-form-text" required>
				<input type="text" name="senders_email" placeholder="Your Email" id="input-fields" class="chis-form-text" required>
				<input type="text" name="senders_subject" placeholder="Your Subject" id="input-fields" class="chis-form-text" required>
				<textarea cols="5" rows="5" name="senders_message" class="chis-form-textarea" placeholder="Your message" required></textarea>
				<input type="submit" name="save_chis_message" value="Send!">
			</form>
		</div>';
}




function display_form_field(){
	global $wpdb;
	$table_name2=$wpdb->prefix . 'chis_messages_settings';
	$messages=$wpdb->get_results("SELECT * FROM $table_name2");
	echo $wpdb->num_rows;
	echo $messages[0]->admin_email;
	//echo mysql_num_rows($messages);
	foreach ($messages as $message) {
		$senders_email=$message->admin_email;
		$senders_subject=$message->admin_subject;
		$senders_body=$message->admin_message_body;
		echo'<div class="text-form-admin-container">
			<form action="#" method="post">';
			echo'<input type="text" name="senders_email" value="'.$senders_email.'" placeholder="Enter Senders Name" class="text-form-admin"/>';
			echo'<input type="text" name="senders_subject" value="'.$senders_subject.'" placeholder="Enter Senders Name" class="text-form-admin"/>';
			echo'<textarea name="senders_body" cols="30"  rows="5" class="textarea-form-admin">'.$senders_body.'</textarea>
			</div>';
			echo'<div class="btn-form-admin-container">
					<input type="submit" name="save_settings" value="Save!" class="button button-primary submit-btn" id="submit">
				</div>';
		echo'</form>';
		
	}

	if(isset($_POST['save_settings'])){
		$update_result='<div class="text-form-admin-container">
				<div class="text_notification">pdated Successful!</div>
			</div';
		$senders_email_post=$_POST['senders_email'];
		$senders_subject_post=$_POST['senders_subject'];
		$senders_body_post=$_POST['senders_body'];
		$table_name= $wpdb->prefix . 'chis_messages_settings';
		$wpdb->update(
			$table_name,
			array('admin_email'=>$senders_email_post,'admin_subject'=>$senders_subject_post,'admin_message_body'=>$senders_body_post),
			array('id'=>'1')

		);
	}

}

?>