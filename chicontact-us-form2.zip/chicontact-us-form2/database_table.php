<?php

	function jal_install1() {
		global $wpdb;
		global $jal_db_version;

		$table_name1 = $wpdb->prefix . 'chis_messages';
		
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE $table_name1 (
			id mediumint(9) NOT NULL AUTO_INCREMENT,
			time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
			name tinytext NOT NULL,
			text text NOT NULL,
			email varchar(40) DEFAULT '' NOT NULL,
			subject text(100) DEFAULT '' NOT NULL,
			message text(800) DEFAULT '' NOT NULL,
			UNIQUE KEY id (id)
		) $charset_collate;";

		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $sql );

		add_option( 'jal_db_version', $jal_db_version );
	}



function jal_install2() {
		global $wpdb;
		global $jal_db_version;

		$table_name2 = $wpdb->prefix . 'chis_messages_settings';
		
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE $table_name2 (
			id mediumint(9) NOT NULL AUTO_INCREMENT,
			time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
			admin_name tinytext NOT NULL,
			text text NOT NULL,
			admin_email varchar(40) DEFAULT '' NOT NULL,
			admin_subject text(100) DEFAULT '' NOT NULL,
			admin_message text(800) DEFAULT '' NOT NULL,
			UNIQUE KEY id (id)
		) $charset_collate;";

		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $sql );

		add_option( 'jal_db_version', $jal_db_version );
	}



//add initial data
function jal_install_data() {
	global $wpdb;
	
	$id='1';
	$admin_name = 'Mr WordPress';
	$admin_email = 'myemail@gmail.com';
	$admin_subject='Hello,';
	$admin_message_body='Thanks for stoping by, we will get back to you shortly';
	
	$table_name = $wpdb->prefix . 'chis_messages_settings';
	
	$wpdb->insert( 
		$table_name, 
		array( 
			'id'=>'1',
			'admin_name' => $admin_name, 
			'admin_email' => $admin_email, 
			'admin_subject' => $admin_subject,
			'admin_message_body' => $admin_message_body 
		) 
	);
}

?>